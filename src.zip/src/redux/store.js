import { configureStore } from "@reduxjs/toolkit";
import taskReducer from "./taskSlice";
import thunk from "redux-thunk";

const store = configureStore({
    reducer: {
        tasks: taskReducer,
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(thunk),
});

export default store;
