import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

// Async action to fetch tasks from API
export const fetchTasks = createAsyncThunk("tasks/fetchTasks", async () => {
    const response = await fetch("https://dummyjson.com/todos");
    const data = await response.json();
    
    // Categorizing tasks into different columns
    const categorizedTasks = {
        toDo: [],
        inProgress: [],
        peerReview: [],
        done: []
    };

    data.todos.forEach((task) => {
        if (task.completed) {
            categorizedTasks.done.push(task);
        } else {
            categorizedTasks.toDo.push(task);
        }
    });

    return categorizedTasks;
});

const taskSlice = createSlice({
    name: "tasks",
    initialState: { toDo: [], inProgress: [], peerReview: [], done: [], loading: false, error: null },
    reducers: {
        addTask: (state, action) => {
            state.toDo.push(action.payload);
        },
        moveTask: (state, action) => {
            const { taskId, sourceColumn, destinationColumn } = action.payload;

            let task = state[sourceColumn].find((task) => task.id === taskId);
            if (task) {
                state[sourceColumn] = state[sourceColumn].filter((task) => task.id !== taskId);
                state[destinationColumn].push({ ...task, completed: destinationColumn === "done" });
            }
        },
        editTask: (state, action) => {
            const { column, taskId, title, description } = action.payload;
            let task = state[column].find((task) => task.id === taskId);
            if (task) {
                task.title = title;
                task.description = description;
            }
        },
        deleteTask: (state, action) => {
            const { column, taskId } = action.payload;
            state[column] = state[column].filter((task) => task.id !== taskId);
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchTasks.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchTasks.fulfilled, (state, action) => {
                state.loading = false;
                state.toDo = action.payload.toDo;
                state.inProgress = action.payload.inProgress;
                state.peerReview = action.payload.peerReview;
                state.done = action.payload.done;
            })
            .addCase(fetchTasks.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message;
            });
    },
});

export const { addTask, moveTask, editTask, deleteTask } = taskSlice.actions;
export default taskSlice.reducer;
