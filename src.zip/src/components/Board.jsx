import React, { useState, useEffect } from "react";
import { DragDropContext } from "react-beautiful-dnd";
import Column from "./Column";
import TaskForm from "./TaskForm";
import "./styles.css";

export default function Board() {
    const [tasks, setTasks] = useState({
        todo: [],
        inProgress: [],
        peerReview: [],
        done: []
    });
    const [searchQuery, setSearchQuery] = useState("");
    const [showForm, setShowForm] = useState(false);

    useEffect(() => {
        fetch("https://jsonplaceholder.typicode.com/todos?_limit=10")
            .then(response => response.json())
            .then(json => {
                setTasks({
                    todo: json.filter(task => !task.completed),
                    inProgress: [],
                    peerReview: [],
                    done: json.filter(task => task.completed)
                });
            });
    }, []);

    const handleDragEnd = ({ source, destination }) => {
        if (!destination || source.droppableId === destination.droppableId) return;

        const sourceCol = source.droppableId;
        const destCol = destination.droppableId;
        const task = tasks[sourceCol][source.index];

        setTasks(prev => {
            const newSource = [...prev[sourceCol]];
            newSource.splice(source.index, 1);

            const newDest = [...prev[destCol]];
            newDest.splice(destination.index, 0, task);

            return { ...prev, [sourceCol]: newSource, [destCol]: newDest };
        });
    };

    const addTask = (newTask) => {
        setTasks(prev => ({ ...prev, todo: [newTask, ...prev.todo] }));
        setShowForm(false);
    };

    return (
        <DragDropContext onDragEnd={handleDragEnd}>
            <div className="header">
                <h2>Kanban Board</h2>
                <input
                    type="text"
                    placeholder="Search tasks..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                />
            </div>
            <div className="board" style={{ display: "flex", gap: "20px", overflowX: "auto", padding: "20px" }}>
                <Column title="To Do" tasks={tasks.todo} id="todo" searchQuery={searchQuery} />
                <Column title="In Progress" tasks={tasks.inProgress} id="inProgress" searchQuery={searchQuery} />
                <Column title="Peer Review" tasks={tasks.peerReview} id="peerReview" searchQuery={searchQuery} />
                <Column title="Done" tasks={tasks.done} id="done" searchQuery={searchQuery} />
            </div>
            <button className="add-task-btn" onClick={() => setShowForm(true)}>+</button>
            {showForm && <TaskForm addTask={addTask} closeForm={() => setShowForm(false)} />}
        </DragDropContext>
    );
}